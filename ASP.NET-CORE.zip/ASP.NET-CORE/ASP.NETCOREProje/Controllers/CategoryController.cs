﻿using Microsoft.AspNetCore.Mvc;

namespace ASP.NETCOREProje.Controllers
{
    public class CategoryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
